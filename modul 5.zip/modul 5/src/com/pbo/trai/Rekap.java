package com.pbo.trai;

import java.util.Scanner;

public class Rekap {
	Scanner s = new Scanner(System.in);
    public int nilai;
    public String matkul;
    public String nama;
    
	public int getNilai() {
		return nilai;
	}
	public void setNilai(int nilai) {
		this.nilai = nilai;
	}
	
	public String getMatkul() {
		return matkul;
	}
	
	public void setMatkul(String matkul) {
		this.matkul = matkul;
	}
	
	public String getNama() {
		return nama;
	}
	
	public void setNama(String nama) {
		this.nama = nama;
	}

   

}