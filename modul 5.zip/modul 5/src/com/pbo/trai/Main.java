package com.pbo.trai;

public class Main {
    public static void main(String[] args) {
    
    Rekap r = new Rekap();
     try {
    	 r.setNilai(90);
         r.setMatkul("Pemrograman ");
         r.setNama("Tahmid ganteng :D ");
     } catch (Exception e) {
         e.getMessage();
         System.out.println("tidak boleh ada null :) ");
     }
     finally {
     System.out.println("\nNama Mahasiswa      :  " + r.getNama()); 
     System.out.println("Matkul UTS Mahasiswa  :  " + r.getMatkul());
     System.out.println("Nilai UTS Mahasiswa   :  " + r.getNilai());
   }
 }
}
