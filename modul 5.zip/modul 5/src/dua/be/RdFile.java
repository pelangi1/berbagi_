package dua.be;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class RdFile {
    
    public static void main(String[] args){
        
        try{
            File file = new File("src/ken.txt");
            Scanner scan = new Scanner(file);
           
            while(scan.hasNextLine()){
                String getData = scan.nextLine();
                System.out.println(getData);
            }
            /**
             * jika file yang dicari tidak ada maka 
             * akan di lempar
             */
            scan.close();
            //menutup file otomatis setelah menampilkan
        }catch (FileNotFoundException ex){
            //output pesan ketika file tidak ditemukan
            System.out.println("File gada gan:') "); 
            ex.getMessage();
        }
    }
}