package dua.be;

import java.io.FileNotFoundException;
import java.util.Formatter;
//import java.util.Scanner;

public class WriteF {
	private int nilai;
	private String Matkul;
	private String nama;
    public static void main(String[] args){
            
           
            
         try (Formatter file = new Formatter("src/newFile.txt")) {
             //Scanner s = new Scanner(System.in); 
        	 
             file.format("\nPemrograman ");
             file.format("\nInformatika");
             file.format("\nSaya ganteng hehe:v");
            
        }catch(FileNotFoundException ex){
            
            System.out.println("File Tidak Ditemukan" ); 
           
        }
    
}
	public int getNilai() {
		return nilai;
	}
	public void setNilai(int nilai) {
		this.nilai = nilai;
	}
	public String getMatkul() {
		return Matkul;
	}
	public void setMatkul(String matkul) {
		Matkul = matkul;
	}
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
}