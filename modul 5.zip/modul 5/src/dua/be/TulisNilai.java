/**
 * @author rahmat tahmid a
 */
package dua.be;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import com.pbo.trai.Rekap;

public class TulisNilai {
	static Scanner a = new Scanner(System.in);
	static Rekap rn = new Rekap();
	public static void main(String[] args) throws IOException{
		
		try {
			mainn();
			String dt1 = "\nNama     :  ";
			String dt2 = "\nMatkul   :  ";
			String dt3 = "\nNilai    :  ";
		
			String isi = rn.getNama(); 
			String isi2 = rn.getMatkul(); 
			String isi3 = Integer.toString(rn.getNilai());
			
			FileWriter f;
			BufferedWriter b;
			
			f = new FileWriter("src/ken.txt");
			b = new BufferedWriter(f);
			
			b.write(dt1);b.write(isi);
			b.write(dt2);b.write(isi2);
			b.write(dt3);b.write(isi3);
			b.close();
			f.close();
			
		} catch (IOException e) {
			System.out.println(" input Ssalah ");
			e.getMessage();
		}finally {
			System.out.println("Data Berhasil diinput");
		}
	}
	static void mainn() throws IOException {
		System.out.print("masukkan nama    : ");
		String nama = a.nextLine();
		System.out.print("masukkan matkul  :  ");
		String matkul = a.nextLine();
		System.out.print("masukkan nilai   :  ");
		int n = a.nextInt();
		
		rn.setNilai(n);
		rn.setNama(nama);
		rn.setMatkul(matkul);
		
		System.out.println("\n\n ====== Hasil ======");
		System.out.println("Nama	    : " + rn.getNama());
		System.out.println("matkul anda : " + rn.getMatkul());
		System.out.println("Nilai       : " + rn.getNilai());
		
	}
}