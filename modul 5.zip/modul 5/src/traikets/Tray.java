package traikets;

import java.util.Scanner;

public class Tray {

	public static void main(String[] args) {
		Scanner ne = new Scanner(System.in); 
		try {
			int[] a = new int[4];
			System.out.println("Acces element three : " + a[2]);
			
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Exception throw : " + e);
		} catch (ArrayStoreException a) {
			System.out.println(a);
		}
		System.out.println("out of the block");
	}

}
